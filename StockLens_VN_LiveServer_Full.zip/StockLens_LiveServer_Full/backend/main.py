"""StockLens API — real data only; reused research modules from group project."""
from __future__ import annotations
import io, os, re, json, math, zipfile, tempfile, datetime as dt
from pathlib import Path
from functools import lru_cache
from typing import Optional
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Query, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from analyzer import load_data, analyze, companies, company_info
from fundamentals import get_fundamentals
from news import get_news, sentiment
from report import build_pdf

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'data'; DATA.mkdir(exist_ok=True)
app=FastAPI(title='StockLens VN API',version='2.0')
app.add_middleware(CORSMiddleware,allow_origins=['http://127.0.0.1:5500','http://localhost:5500','http://127.0.0.1:5501','http://localhost:5501','null'],allow_methods=['GET','POST'],allow_headers=['*'])

def clean(v):
    if isinstance(v,(np.integer,)): return int(v)
    if isinstance(v,(np.floating,float)): return None if not math.isfinite(float(v)) else float(v)
    if isinstance(v,(pd.Timestamp,dt.date,dt.datetime)): return str(v)
    if isinstance(v,pd.DataFrame): return [clean(x) for x in v.to_dict('records')]
    if isinstance(v,(list,tuple,np.ndarray)): return [clean(x) for x in v]
    if isinstance(v,dict): return {str(k):clean(x) for k,x in v.items()}
    if isinstance(v,(str,int,bool)) or v is None:return v
    return str(v)

def validate(t):
    t=t.strip().upper()
    if not re.fullmatch(r'[A-Z0-9]{2,10}',t): raise HTTPException(400,'Mã chứng khoán không hợp lệ')
    return t

def researched(t):
    # Fail closed: group BCTC present, but prices must be obtained from real API.
    d=load_data(t,demo=False); a=analyze(d)
    return d,a

def core(d,a,profile=None):
    scores=clean(a.get('scores',{})); prof=profile or {}
    risk=float(prof.get('max_drawdown',20)); desired=float(prof.get('target_return',15))
    horizon=int(prof.get('horizon_months',12))
    capital=float(prof.get('capital',100_000_000))
    risk_trade=float(prof.get('trade_risk',1))
    atr=clean(a.get('atr'))
    price=clean(a.get('price'))
    target=clean(a.get('target'))
    implied=(target/price-1)*100 if target and price else None
    goal=(1+desired/100)**(horizon/12)-1
    # This is a transparent screening heuristic, NOT a realized risk forecast.
    gap=round((implied-goal*100),2) if implied is not None else None
    per_share=2*atr if atr and atr>0 else None
    units=math.floor(min(capital*risk_trade/100/per_share, capital*.1/price)/100)*100 if per_share and price else None
    return clean({'ticker':d['ticker'],'name':d.get('name'),'industry':d.get('industry'),'last_session':d.get('last_session'),
     'source':d.get('source'),'price':price,'target_price':target,'implied_upside_pct':implied,
     'total':a.get('total'),'recommendation':a.get('rec'),'scores':scores,'comments':a.get('comments',[]),
     'rsi':a.get('rsi'),'atr':atr,'stop':a.get('stop'),'financial':d.get('fin'),
     'prices':a.get('px',d.get('prices')),'index':d.get('index'),
     'goal':{'capital':capital,'max_drawdown_pct':risk,'target_return_annual_pct':desired,'horizon_months':horizon,
      'trade_risk_pct':risk_trade,'target_for_horizon_pct':goal*100,'gap_vs_goal_pct':gap,
      'position_shares_reference':units,'note':'So sánh mục tiêu với định giá mô hình, không đảm bảo lợi suất hay giới hạn lỗ.'}})

class Profile(BaseModel):
    capital:float=Field(100_000_000,gt=0,le=1e13)
    max_drawdown:float=Field(20,ge=1,le=80)
    target_return:float=Field(15,ge=0,le=200)
    horizon_months:int=Field(12,ge=1,le=120)
    trade_risk:float=Field(1,gt=0,le=5)
class ReportRequest(BaseModel):
    tickers:list[str]=Field(min_length=1,max_length=8)
    profile:Profile=Field(default_factory=Profile)
    sections:list[str]=['overview','financial','technical','news','risk']

@app.get('/api/health')
def health():
    paths={k:sum(1 for _ in DATA.rglob(glob)) for k,glob in {'annual_reports':'*.pdf','financial_parquet':'*.parquet','news_files':'*news*.csv','price_csv':'*price*.csv'}.items()}
    return {'status':'ok','project':'StockLens VN','data_files':paths,'real_only':True,'date':dt.date.today().isoformat()}

@app.get('/api/companies')
def list_companies(q:str='',exchange:str='',industry:str='',limit:int=100):
    df=companies().reset_index(); df=df.fillna('')
    if q:df=df[df.astype(str).apply(lambda c:c.str.contains(q,case=False,regex=False)).any(axis=1)]
    if exchange:df=df[df['exchange'].str.contains(exchange,case=False,regex=False)]
    if industry:df=df[df['icb1'].str.contains(industry,case=False,regex=False)|df['icb3'].str.contains(industry,case=False,regex=False)]
    return clean({'total':len(df),'items':df.head(min(limit,2000))[['ticker','name','exchange','icb1','icb2','icb3','icb4']].to_dict('records')})

@app.get('/api/financial/{ticker}')
def financial(ticker:str,years:int=6):
    t=validate(ticker); f=get_fundamentals(t,n_years=years)
    if f.empty:raise HTTPException(404,'Chưa có dữ liệu BCTC cho mã này trong bộ dữ liệu của nhóm')
    return clean({'ticker':t,'source':'BCTC HSX/HNX trong kho dữ liệu nhóm','items':f})

@app.get('/api/analysis/{ticker}')
def analysis(ticker:str, capital:float=100000000,max_drawdown:float=20,target_return:float=15,horizon_months:int=12,trade_risk:float=1):
    t=validate(ticker)
    try:d,a=researched(t)
    except Exception as ex:raise HTTPException(503,f'Chưa phân tích được {t} bằng dữ liệu thị trường thật: {str(ex)[:220]}. Kiểm tra VNStock/API giá hoặc bổ sung lịch sử OHLCV.')
    p=Profile(capital=capital,max_drawdown=max_drawdown,target_return=target_return,horizon_months=horizon_months,trade_risk=trade_risk)
    return core(d,a,p.model_dump())

EVENTS={'Kết quả kinh doanh':['lợi nhuận','doanh thu','báo lãi','báo lỗ'],'Cổ tức / phát hành':['cổ tức','phát hành','esop'],'Dự án / hợp đồng':['dự án','trúng thầu','hợp đồng'],'Pháp lý / rủi ro':['xử phạt','điều tra','vi phạm'],'Quản trị':['bổ nhiệm','miễn nhiệm','hội đồng quản trị'],'Vĩ mô / ngành':['lãi suất','tỷ giá','chính sách']}
def classify(title):
    s=str(title).lower()
    for k,keywords in EVENTS.items():
        if any(w in s for w in keywords):return k
    return 'Khác'

@app.get('/api/news/{ticker}')
def news(ticker:str, days:int=90, category:str='',mood:str='',keyword:str=''):
    t=validate(ticker)
    try:r=get_news(t,company_info(t)['name'],limit=120,days=days); df=r.get('items',pd.DataFrame())
    except Exception as e:raise HTTPException(503,f'Không thể tải tin tức: {e}')
    if df.empty:return {'ticker':t,'items':[],'message':'Chưa có bài báo trong nguồn hiện tại'}
    df=df.rename(columns={'link':'url'}).copy()
    if 'title' not in df:raise HTTPException(503,'Nguồn tin chưa trả về tiêu đề')
    df['category']=df['title'].map(classify)
    df['sentiment_score']=df['title'].map(sentiment)
    df['sentiment']=df['sentiment_score'].map(lambda n:'Tích cực' if n>.1 else ('Tiêu cực' if n<-.1 else 'Trung lập'))
    df['priority_score']=(50+df['sentiment_score'].abs()*30+df['category'].map(lambda x:15 if x in ('Pháp lý / rủi ro','Kết quả kinh doanh') else 5)).clip(0,100)
    if category:df=df[df['category']==category]
    if mood:df=df[df['sentiment']==mood]
    if keyword:df=df[df['title'].astype(str).str.contains(keyword,case=False,regex=False)]
    return clean({'ticker':t,'source':r.get('source'),'items':df.head(120),'disclaimer':'Điểm ưu tiên dựa trên từ khóa; không phải dự báo tác động đến giá.'})

@app.get('/api/screener')
def screener(q:str='', industry:str='',exchange:str='',limit:int=200):
    # Screener of metadata is offline; full financial scoring requires price data.
    return list_companies(q=q,industry=industry,exchange=exchange,limit=limit)

@app.post('/api/assistant')
def assistant(payload:dict=Body(...)):
    q=str(payload.get('question','')).strip(); t=validate(str(payload.get('ticker','FPT')))
    if not q:raise HTTPException(400,'Vui lòng nhập câu hỏi')
    try:d,a=researched(t)
    except Exception as ex:return {'answer':f'Chưa đủ dữ liệu giá thực tế cho {t} để trả lời có căn cứ. {str(ex)[:150]}','mode':'data-unavailable'}
    s=a.get('scores',{})
    answer=f'{t}: điểm phân tích {a.get("total")}/100, trạng thái {a.get("rec")}. '+ '; '.join(a.get('comments',[])[:3])
    ql=q.lower()
    if 'rủi ro' in ql or 'cắt lỗ' in ql:answer=f'ATR: {a.get("atr")}; mức dừng lỗ tham khảo: {a.get("stop")}. Không phải mức lỗ được bảo đảm.'
    elif 'định giá' in ql or 'mục tiêu' in ql:answer=f'Điểm định giá {s.get("valuation")}; giá mục tiêu theo mô hình {a.get("target")}. Cần kiểm tra giả định của phương pháp định giá.'
    elif 'nguồn' in ql:answer=f'Nguồn dữ liệu: {d.get("source")}; dữ liệu giá gần nhất: {d.get("last_session")}.'
    return clean({'answer':answer,'mode':'rule-based-grounded','ticker':t})

@app.get('/api/annual-reports')
def annual_reports(ticker:str='',year_from:int=2000,year_to:int=2100):
    # Only index locally available PDFs; never claim remote archive exists locally.
    found=[]
    for p in (DATA/'annual_reports').rglob('*.pdf') if (DATA/'annual_reports').exists() else []:
        name=p.stem.upper(); y=re.search(r'20\d{2}',name)
        if ticker and ticker.upper() not in name:continue
        if y and not year_from<=int(y.group())<=year_to:continue
        found.append({'file':str(p.relative_to(DATA)),'year':int(y.group()) if y else None,'size_bytes':p.stat().st_size})
    return {'items':found[:500],'total':len(found),'note':'Chỉ liệt kê tài liệu PDF được thêm vào data/annual_reports.'}

@app.get('/api/dictionaries')
def dictionaries():
    return {'items':[{'name':'Bộ từ khóa sự kiện doanh nghiệp','terms':EVENTS},{'name':'Bộ từ khóa sắc thái tin','terms':{'Tích cực':['tăng trưởng','vượt kế hoạch','trúng thầu'],'Tiêu cực':['thua lỗ','xử phạt','giảm mạnh']}}]}

@app.post('/api/report')
def report(request:ReportRequest):
    items=[]; failures=[]
    for ticker in dict.fromkeys(request.tickers):
        try:d,a=researched(validate(ticker)); items.append((d,a,core(d,a,request.profile.model_dump())))
        except Exception as ex:failures.append({'ticker':ticker,'error':str(ex)[:180]})
    if not items:raise HTTPException(422,{'message':'Không có mã nào đủ dữ liệu thật để tạo PDF','failures':failures})
    from fpdf import FPDF
    from report import _font_paths
    font_paths=_font_paths()
    pdf=FPDF();pdf.set_auto_page_break(auto=True,margin=18)
    regular,bold=font_paths
    pdf.add_font('VN','',regular); pdf.add_font('VN','B',bold)
    def line(s,size=10,bold=False):
        pdf.set_font('VN','B' if bold else '',size);pdf.multi_cell(0,6,str(s))
    pdf.add_page();line('STOCKLENS VN | BÁO CÁO NGHIÊN CỨU ĐẦU TƯ',18,True)
    line('Ngày tạo: '+dt.datetime.now().strftime('%d/%m/%Y %H:%M'))
    line('Các mã: '+', '.join(d['ticker'] for d,_,_ in items))
    p=request.profile;line(f'Vốn giả định: {p.capital:,.0f} VND | Sụt giảm chấp nhận: {p.max_drawdown}% | Lợi suất mục tiêu: {p.target_return}%/năm')
    line(f'Thời gian: {p.horizon_months} tháng | Ngân sách rủi ro/lệnh: {p.trade_risk}%')
    line('TỔNG HỢP SO SÁNH',13,True)
    for d,a,c in items:line(f'{d["ticker"]}  |  Điểm {a.get("total")}/100  |  {a.get("rec")}  |  Giá {c.get("price")}  |  Dư địa {c.get("implied_upside_pct")} %')
    if failures:line('Mã không đủ dữ liệu: '+', '.join(f['ticker'] for f in failures))
    for d,a,c in items:
        pdf.add_page();line(d['ticker']+' — '+str(d.get('name','')),17,True)
        line('Điểm StockLens: '+str(a.get('total'))+' / 100  |  '+str(a.get('rec')))
        if 'financial' in request.sections:
            line('CHỈ SỐ TÀI CHÍNH',12,True)
            f=d.get('fin',pd.DataFrame())
            for row in f.tail(5).to_dict('records'):
                line(f"{row.get('year')}: Doanh thu {row.get('revenue')}, LNST {row.get('npat')}, ROE {row.get('roe')}",9)
        if 'risk' in request.sections:
            line('QUẢN TRỊ RỦI RO CÁ NHÂN HÓA',12,True)
            line(f"ATR: {c.get('atr')} | Mốc dừng lỗ tham khảo: {c.get('stop')} | Số CP tham khảo: {c['goal'].get('position_shares_reference')}")
            line('Mức lỗ thực tế có thể vượt ngưỡng đặt trước do biến động giá / thanh khoản.')
        for comment in a.get('comments',[])[:6]:line('• '+str(comment),9)
        if 'technical' in request.sections:line('Đồ thị tương tác được xem trên website; PDF cung cấp tóm tắt định lượng.',9)
        if 'news' in request.sections:line('Tin tức: xem nguồn và ngày công bố trực tiếp trên trang Tin tức của StockLens.',9)
        line('Nguồn: '+str(d.get('source',''))+' | Chỉ phục vụ học tập và nghiên cứu.',9)
    result=bytes(pdf.output())
    filename='StockLens_'+('_'.join(d['ticker'] for d,_,_ in items))+'.pdf'
    return StreamingResponse(io.BytesIO(result),media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="{filename}"'})

class MineRequest(BaseModel):
    files:list[str]=Field(min_length=1,max_length=15)
    topics:list[str]=Field(default_factory=lambda:['chuyển đổi số','ESG','rủi ro','tăng trưởng','blockchain'])

@app.post('/api/annual-mine')
def annual_mine(request:MineRequest):
    """Extract searchable text only from PDFs explicitly placed into the local project corpus."""
    try:
        import fitz
    except ImportError:
        raise HTTPException(503,'Thiếu PyMuPDF: cài python -m pip install pymupdf')
    from unicodedata import normalize
    def norm(s):
        return ''.join(c for c in normalize('NFD',str(s).lower().replace('đ','d')) if __import__('unicodedata').category(c)!='Mn')
    root=(DATA/'annual_reports').resolve();output=[]
    for rel in request.files:
        path=(DATA/rel).resolve()
        if not path.is_relative_to(root) or path.suffix.lower()!='.pdf' or not path.is_file():
            raise HTTPException(400,'Tên báo cáo không hợp lệ hoặc không tồn tại trong kho nội bộ')
        try:
            doc=fitz.open(path)
            if len(doc)>1000: raise ValueError('Tài liệu vượt quá 1.000 trang')
            text='\n'.join(page.get_text() for page in doc)
            normalized=norm(text)
            output.append({'file':rel,'pages':len(doc),'characters':len(text),
                'topic_counts':{k:normalized.count(norm(k)) for k in request.topics[:30]},
                'status':'ok' if text.strip() else 'PDF dạng ảnh: cần OCR'})
        except Exception as ex:
            output.append({'file':rel,'error':str(ex)[:180]})
    return {'items':output,'method':'Đếm từ/cụm từ trên văn bản trích xuất. Không suy ra tác động tài chính hoặc tần suất chuẩn hóa theo số trang.'}
