# STOCKLENS VN — Live Server + Python FastAPI

## Chạy trên Windows / VS Code

1. Giải nén và mở **thư mục StockLens_LiveServer_Full** bằng VS Code.
2. Mở PowerShell ở thư mục gốc, chạy:

```powershell
py -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt --extra-index-url https://vnstocks.com/api/simple
```

3. Terminal **backend** (đứng ở thư mục gốc):

```powershell
cd backend
python -m uvicorn main:app --reload --port 8000
```

4. Mở Terminal khác, trong VS Code cài tiện ích **Live Server** của Ritwick Dey (nếu chưa có). Nhấp chuột phải **frontend/index.html → Open with Live Server**. URL thường là `http://127.0.0.1:5500/frontend/index.html`. Nếu mở `frontend` làm workspace thì có thể là `http://127.0.0.1:5500`.

5. Kiểm tra backend: `http://127.0.0.1:8000/docs` hoặc `/api/health`.

## Tầng dữ liệu

- `data/companies_icb.csv`: danh sách HSX/HNX, ngành ICB.
- `data/bctc/`: bốn Parquet BCTC từ file nhóm gửi (HSX/HNX: income, balance).
- Giá OHLCV / VN-Index: module `backend/analyzer.py` lấy dữ liệu **thực** thông qua VNStock/VCI; yêu cầu Internet. Không sử dụng `demo=True`.
- Tin tức: `backend/news.py` thử VNStock và Google News RSS; phải kiểm tra nội dung, sự liên quan, nguồn và ngày đăng.
- PDF báo cáo thường niên: thêm các file **có quyền sử dụng** vào `data/annual_reports/`, đặt tên `FPT_2024.pdf`... Trang Kho BCTN sẽ hiển thị các PDF có thật.
- API keys (nếu phát triển AI LLM): giữ trên backend qua biến môi trường, **không** đưa vào JS/GitHub.

## Các tính năng hiện thực hóa và giới hạn

- Hoạt động qua API: danh mục công ty, tra cứu BCTC, phân tích giá/chỉ số khi VNStock truy cập được, tin tức có phân loại, lọc theo sàn-ngành, danh mục vốn giả định, hồ sơ đầu tư, trợ lý giải thích, báo cáo PDF đa mã.
- Trang backtest hiện **chưa tính hiệu quả lịch sử** vì chưa có engine chống look-ahead và dữ liệu lịch sử được kiểm định. Giao diện báo rõ trạng thái.
- Kho BCTN: **liệt kê và lọc tệp PDF thật**, chưa triển khai trích xuất toàn văn hoặc cào 14.528 báo cáo từ kho ngoài.
- Tin tức: điểm ưu tiên theo từ khóa là sơ bộ, không phải xác suất giá cổ phiếu tăng.
- Mục tiêu lợi suất/rủi ro: chỉ dùng để giải thích và ước tính vị thế tham khảo, không bảo đảm đạt mức lợi nhuận hay mức lỗ đã nhập.
- Bot: trợ lý giải thích theo quy tắc, **chưa** có API LLM.
- Báo cáo PDF: đa mã có bảng so sánh và các phần tài chính/rủi ro, nhưng chưa nhúng đầy đủ đồ thị và tin từng sự kiện; muốn có cần bổ sung module dựng báo cáo tương ứng.

## Dữ liệu nhóm cần bổ sung nếu muốn đủ những tính năng theo ảnh

1. Dữ liệu giá OHLCV và VN-Index lịch sử có nguồn xác thực và ngày, để có chế độ offline, quét kỹ thuật hàng loạt, backtest.
2. Dữ liệu bài báo đầy đủ: `ticker, title, content, published_at, source, url`, để lọc tin chuyên sâu và liên kết giá–sự kiện.
3. Kho BCTN PDF (hoặc đường dẫn tải hợp pháp và index metadata) để trích xuất/tìm kiếm nội dung.
4. Dữ liệu giao dịch intraday nếu muốn điểm BUY/SELL trên nến 15 phút như chiến lược thứ hai.

## Lưu ý

Phiên bản này dùng lại code nguồn `analyzer.py`, `fundamentals.py`, `news.py`, `screener.py`, `report.py` do nhóm cung cấp. Cần giữ ghi công tác giả nguồn khi tái sử dụng phần của dự án tham khảo và kiểm tra quyền dùng dữ liệu.
