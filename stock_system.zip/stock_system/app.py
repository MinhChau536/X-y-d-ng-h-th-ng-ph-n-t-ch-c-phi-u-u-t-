"""
Giao diện web:  streamlit run app.py
"""
import datetime as dt
import os

import pandas as pd
import streamlit as st

from analyzer import load_data, analyze
from report import build_pdf, chart_price, chart_fin, chart_rel

st.set_page_config(page_title="Phân tích cơ hội đầu tư cổ phiếu", page_icon="📈", layout="wide")
st.title("📈 Hệ thống phân tích cơ hội đầu tư cổ phiếu")
st.caption("Nhập mã cổ phiếu → hệ thống lấy dữ liệu, chấm điểm 3 trụ cột và xuất báo cáo PDF tự động.")

with st.sidebar:
    st.header("Thiết lập")
    mode = st.radio("Chế độ", ["Phân tích từng mã", "Quét thị trường"])
    if mode == "Phân tích từng mã":
        tickers = st.text_input("Mã cổ phiếu (cách nhau dấu phẩy)", "FPT")
    else:
        group = st.selectbox("Rổ cổ phiếu", ["VN30", "VN100", "HNX30", "VNMidCap", "HOSE", "HNX"])
        top_n = st.slider("Xuất PDF chi tiết cho top", 0, 10, 3)
        st.caption("Bản miễn phí vnstock giới hạn request/phút: VN30 mất vài phút, HOSE có thể tới 30–60 phút.")
    demo = st.toggle("Dùng dữ liệu mô phỏng (khi API lỗi)", value=False)
    run = st.button("Chạy", type="primary", use_container_width=True)
    st.markdown("---")
    st.markdown("**Trọng số:** Chất lượng 35% · Định giá 30% · Động lượng 25% · Tin tức 10%")


def show(ticker):
    with st.spinner(f"Đang lấy dữ liệu {ticker}..."):
        data = load_data(ticker, demo=demo)
        a = analyze(data)

    st.subheader(f"{data['ticker']} – {data['name']}")
    if demo:
        st.warning("Đang dùng DỮ LIỆU MÔ PHỎNG, không phản ánh thực tế.")
    c = st.columns(5)
    c[0].metric("Khuyến nghị", a["rec"], f"{a['total']:.0f}/100 điểm", delta_color="off")
    c[1].metric("Giá hiện tại", f"{a['price']:,.0f}")
    c[2].metric("Giá mục tiêu", f"{a['target']:,.0f}" if a["target"] else "N/A",
                f"{a['upside']:+.1f}%" if a["upside"] is not None else None)
    c[3].metric("Cắt lỗ gợi ý", f"{a['stop']:,.0f}" if a["stop"] else "N/A")
    c[4].metric("RSI(14)", f"{a['rsi']:.0f}")

    s = a["scores"]
    st.progress(s["quality"] / 100, text=f"Chất lượng DN: {s['quality']:.0f}/100")
    st.progress(s["valuation"] / 100, text=f"Định giá: {s['valuation']:.0f}/100")
    st.progress(s["momentum"] / 100, text=f"Động lượng: {s['momentum']:.0f}/100")

    for cm in a["comments"]:
        st.markdown(f"- {cm}")

    st.image(chart_price(a, data["ticker"]))
    c1, c2 = st.columns(2)
    c1.image(chart_fin(a))
    c2.image(chart_rel(a))

    nw = data.get("news") or {}
    st.markdown(f"**Tin tức gần đây** · nguồn: {nw.get('source')}")
    if nw.get("n"):
        show_news = nw["items"][["date", "title", "sentiment"]].copy()
        show_news["date"] = show_news["date"].dt.strftime("%d/%m/%Y")
        st.dataframe(show_news, use_container_width=True, hide_index=True)

    mk = data.get("market_news") or {}
    if mk.get("n"):
        with st.expander(f"Bối cảnh thị trường · tâm lý {mk['score']:+.2f} · {mk.get('source')}", expanded=False):
            st.write(" | ".join(f"{k}: {v:+.2f}" for k, v in mk.get("by_topic", {}).items()))
            st.dataframe(mk["items"][["topic", "title", "sentiment"]], use_container_width=True, hide_index=True)

    pr = data.get("peers") or {}
    if pr:
        with st.expander(f"So sánh ngành: {pr['group']} ({pr['n']} DN)"):
            st.dataframe(pr["peers"].round(1), use_container_width=True, hide_index=True)
            st.caption(f"Trung vị ngành – ROE {pr['roe']:.1f}%, biên LN {pr['net_margin']:.1f}%, "
                       f"tăng trưởng DT {pr['rev_g']:.1f}%")

    with st.expander("Kiểm soát chất lượng dữ liệu"):
        chk = data.get("check")
        if chk is not None and len(chk):
            st.dataframe(chk.round(2), use_container_width=True, hide_index=True)
        else:
            st.write("Chưa đối chiếu chéo được với vnstock trong lần chạy này.")
        for n_ in data.get("notes", []):
            st.write("• " + n_)

    with st.expander("Bảng chỉ số tài chính & giải trình chấm điểm"):
        st.dataframe(a["fin"].set_index("year").round(2), use_container_width=True)
        for k, name in [("quality", "Chất lượng"), ("valuation", "Định giá"), ("momentum", "Động lượng")]:
            st.markdown(f"**{name}**")
            st.dataframe(pd.DataFrame(a["checks"][k]), use_container_width=True, hide_index=True)

    out = build_pdf(data, a, f"output/{data['ticker']}_{dt.date.today():%Y%m%d}.pdf")
    with open(out, "rb") as f:
        st.download_button(f"⬇️ Tải báo cáo PDF {data['ticker']}", f, file_name=os.path.basename(out),
                           mime="application/pdf", type="primary")
    st.caption(f"Nguồn: {data['source']} · phiên cuối {data['last_session']} · tạo lúc {data['fetched_at']}")
    st.divider()


def show_market():
    from screener import run_screen
    bar = st.progress(0.0, text="Bắt đầu quét...")
    df, mpdf, dpdfs, failed = run_screen(group, demo=demo, top=top_n,
                                         progress=lambda p, m: bar.progress(p, text=m))
    bar.empty()
    counts = df["rec"].value_counts()
    c = st.columns(4)
    c[0].metric("MUA", counts.get("MUA", 0))
    c[1].metric("THEO DÕI / NẮM GIỮ", counts.get("THEO DÕI / NẮM GIỮ", 0))
    c[2].metric("TRÁNH / BÁN", counts.get("TRÁNH / BÁN", 0))
    c[3].metric("Điểm TB", f"{df['total'].mean():.0f}")
    from news import get_market_news, demo_market_news
    mk = demo_market_news() if demo else get_market_news()
    if mk.get("n"):
        st.markdown(f"**Tâm lý thị trường: {mk['score']:+.2f}** · " +
                    " | ".join(f"{k}: {v:+.2f}" for k, v in mk.get("by_topic", {}).items()))
        st.dataframe(mk["items"][["topic", "title", "sentiment"]], use_container_width=True, hide_index=True)
    if failed:
        st.warning("Lỗi dữ liệu: " + ", ".join(t for t, _ in failed))
    st.dataframe(df.round(1), use_container_width=True)
    with open(mpdf, "rb") as f:
        st.download_button("⬇️ Tải PDF sàng lọc thị trường", f, file_name=os.path.basename(mpdf),
                           mime="application/pdf", type="primary")
    for p in dpdfs:
        with open(p, "rb") as f:
            st.download_button(f"⬇️ PDF chi tiết {os.path.basename(p)}", f, file_name=os.path.basename(p),
                               mime="application/pdf")


if run and mode == "Quét thị trường":
    try:
        show_market()
    except Exception as e:
        st.error(f"Quét thất bại: {e}")
elif run:
    for t in [x.strip().upper() for x in tickers.split(",") if x.strip()]:
        try:
            show(t)
        except Exception as e:
            st.error(f"{t}: không lấy được dữ liệu ({e}). Thử lại hoặc bật chế độ dữ liệu mô phỏng.")
