"""
TẦNG 1 + 2: DỮ LIỆU & PHÂN TÍCH
- Lấy giá, chỉ số tài chính, KQKD từ vnstock (nguồn VCI)
- Chế độ demo: dữ liệu mô phỏng (dùng khi API lỗi / không có mạng)
- Tính chỉ báo kỹ thuật, chấm điểm 3 trụ cột, khuyến nghị, giá mục tiêu
"""
from __future__ import annotations

import datetime as dt
import numpy as np
import pandas as pd

# =====================================================================
# 1. LẤY DỮ LIỆU
# =====================================================================

def _flatten(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [" | ".join(str(x) for x in c if str(x) != "") for c in df.columns]
    df.columns = [str(c) for c in df.columns]
    return df


def _pick(df: pd.DataFrame, keys, exclude=()):
    """Tìm cột theo từ khoá (không phân biệt hoa thường) vì tên cột vnstock hay đổi."""
    for c in df.columns:
        lc = c.lower()
        if all(k in lc for k in keys) and not any(e in lc for e in exclude):
            return c
    return None


def _year_col(df):
    return _pick(df, ["yearreport"]) or _pick(df, ["năm"]) or _pick(df, ["year"], exclude=["yoy"])


def _fetch_vnstock(ticker: str, years: int = 3):
    from vnstock import Vnstock  # import muộn để chế độ demo không cần vnstock

    end = dt.date.today()
    start = end - dt.timedelta(days=365 * years)
    stock = Vnstock().stock(symbol=ticker, source="VCI")

    px = stock.quote.history(start=str(start), end=str(end), interval="1D")
    idx = Vnstock().stock(symbol="VNINDEX", source="VCI").quote.history(
        start=str(start), end=str(end), interval="1D")

    ratio = _flatten(stock.finance.ratio(period="year", lang="en", dropna=True))
    inc = _flatten(stock.finance.income_statement(period="year", lang="en", dropna=True))

    # ---- chuẩn hoá bảng chỉ số tài chính theo năm ----
    yc = _year_col(ratio)
    fin = pd.DataFrame({"year": pd.to_numeric(ratio[yc], errors="coerce")})
    mapping = {
        "roe": (["roe"], ()),
        "roa": (["roa"], ()),
        "net_margin": (["net profit margin"], ()),
        "de": (["debt/equity"], ()),
        "pe": (["p/e"], ()),
        "pb": (["p/b"], ()),
        "eps": (["eps"], ()),
        "bvps": (["bvps"], ()),
    }
    for k, (keys, exc) in mapping.items():
        c = _pick(ratio, keys, exc)
        fin[k] = pd.to_numeric(ratio[c], errors="coerce") if c else np.nan

    # tỷ lệ % có thể ở dạng 0.25 -> đổi về 25
    for k in ["roe", "roa", "net_margin"]:
        s = fin[k].dropna()
        if len(s) and s.abs().median() < 1.5:
            fin[k] = fin[k] * 100

    # ---- doanh thu & LNST công ty mẹ ----
    yc2 = _year_col(inc)
    rev_c = _pick(inc, ["revenue"], exclude=["yoy", "growth", "%"])
    np_c = (_pick(inc, ["attribut", "parent"], exclude=["yoy", "%"])
            or _pick(inc, ["net profit"], exclude=["yoy", "%", "margin"]))
    is_df = pd.DataFrame({
        "year": pd.to_numeric(inc[yc2], errors="coerce"),
        "revenue": pd.to_numeric(inc[rev_c], errors="coerce") if rev_c else np.nan,
        "npat": pd.to_numeric(inc[np_c], errors="coerce") if np_c else np.nan,
    })
    fin = fin.merge(is_df, on="year", how="left")
    fin = fin.dropna(subset=["year"]).drop_duplicates("year").sort_values("year").tail(6)
    fin["year"] = fin["year"].astype(int)

    # Đơn vị doanh thu: đưa về tỷ đồng
    for k in ["revenue", "npat"]:
        s = fin[k].dropna()
        if len(s) and s.abs().median() > 1e7:  # đang ở đơn vị đồng
            fin[k] = fin[k] / 1e9

    name = ticker
    try:
        ov = _flatten(stock.company.overview())
        c = _pick(ov, ["organ_name"]) or _pick(ov, ["company_name"]) or _pick(ov, ["short_name"])
        industry = _pick(ov, ["icb_name3"]) or _pick(ov, ["industry"])
        name = str(ov[c].iloc[0]) if c else ticker
        industry = str(ov[industry].iloc[0]) if industry else ""
    except Exception:
        industry = ""

    return dict(prices=_clean_px(px), index=_clean_px(idx), fin=fin,
                name=name, industry=industry, source="vnstock (nguồn VCI – Vietcap)")


def _clean_px(px: pd.DataFrame) -> pd.DataFrame:
    px = px.rename(columns=str.lower).copy()
    px["time"] = pd.to_datetime(px["time"])
    px = px.sort_values("time").drop_duplicates("time").reset_index(drop=True)
    # VCI trả giá theo nghìn đồng -> quy về đồng
    if px["close"].median() < 1000:
        for c in ["open", "high", "low", "close"]:
            px[c] = px[c] * 1000
    return px[["time", "open", "high", "low", "close", "volume"]]


def _fetch_demo(ticker: str, years: int = 3):
    """Dữ liệu MÔ PHỎNG – chỉ để kiểm thử luồng, không dùng để phân tích thật."""
    import zlib
    rng = np.random.default_rng(zlib.crc32(ticker.encode()))
    n = 252 * years
    dates = pd.bdate_range(end=dt.date.today(), periods=n)

    def walk(p0, mu, sig):
        r = rng.normal(mu, sig, n)
        close = p0 * np.exp(np.cumsum(r))
        high = close * (1 + rng.uniform(0, 0.02, n))
        low = close * (1 - rng.uniform(0, 0.02, n))
        opn = (high + low) / 2
        vol = rng.integers(1_000_000, 8_000_000, n)
        return pd.DataFrame(dict(time=dates, open=opn, high=high, low=low, close=close, volume=vol))

    px = walk(rng.uniform(20_000, 120_000), 0.0006, 0.018)
    idx = walk(1_100, 0.0003, 0.011)
    yrs = list(range(dt.date.today().year - 5, dt.date.today().year))
    rev = np.cumprod(rng.uniform(1.0, 1.25, 5)) * rng.uniform(5_000, 50_000)
    margin = rng.uniform(6, 18, 5)
    npat = rev * margin / 100
    fin = pd.DataFrame(dict(
        year=yrs, revenue=rev, npat=npat, net_margin=margin,
        roe=rng.uniform(10, 26, 5), roa=rng.uniform(4, 12, 5), de=rng.uniform(0.3, 1.4, 5),
        pe=rng.uniform(9, 20, 5), pb=rng.uniform(1.2, 3.5, 5),
    ))
    fin["eps"] = px["close"].iloc[-1] / fin["pe"] * rng.uniform(0.9, 1.1, 5)
    fin["bvps"] = px["close"].iloc[-1] / fin["pb"]
    return dict(prices=px, index=idx, fin=fin, name=f"{ticker} (DỮ LIỆU MÔ PHỎNG)",
                industry="Demo", source="DỮ LIỆU MÔ PHỎNG – chỉ dùng kiểm thử")


def load_data(ticker: str, demo: bool = False, years: int = 3) -> dict:
    ticker = ticker.upper().strip()
    data = _fetch_demo(ticker, years) if demo else _fetch_vnstock(ticker, years)
    data["ticker"] = ticker
    data["demo"] = demo
    data["fetched_at"] = dt.datetime.now().strftime("%H:%M %d/%m/%Y")
    data["last_session"] = data["prices"]["time"].iloc[-1].strftime("%d/%m/%Y")
    return data


# =====================================================================
# 2. CHỈ BÁO KỸ THUẬT
# =====================================================================

def add_indicators(px: pd.DataFrame) -> pd.DataFrame:
    px = px.copy()
    px["ma20"] = px["close"].rolling(20).mean()
    px["ma50"] = px["close"].rolling(50).mean()
    px["ma200"] = px["close"].rolling(200).mean()
    delta = px["close"].diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    px["rsi"] = 100 - 100 / (1 + gain / loss.replace(0, np.nan))
    tr = pd.concat([px["high"] - px["low"],
                    (px["high"] - px["close"].shift()).abs(),
                    (px["low"] - px["close"].shift()).abs()], axis=1).max(axis=1)
    px["atr"] = tr.rolling(14).mean()
    return px


def _ret(s: pd.Series, n: int):
    return s.iloc[-1] / s.iloc[-n - 1] - 1 if len(s) > n else np.nan


# =====================================================================
# 3. CHẤM ĐIỂM 3 TRỤ CỘT + KHUYẾN NGHỊ
# =====================================================================

WEIGHTS = {"quality": 0.4, "valuation": 0.3, "momentum": 0.3}


def _check(points, name, cond, pts, value_txt, note=""):
    """Ghi lại từng tiêu chí để in ra bảng giải trình trong PDF."""
    if cond is None:
        points.append(dict(name=name, value=value_txt, ok=None, pts=0, max=0, note="Thiếu dữ liệu"))
    else:
        points.append(dict(name=name, value=value_txt, ok=bool(cond), pts=pts if cond else 0, max=pts, note=note))


def _fmt(x, suf="", d=1):
    return "N/A" if x is None or pd.isna(x) else f"{x:,.{d}f}{suf}"


def analyze(data: dict) -> dict:
    px = add_indicators(data["prices"])
    idx = add_indicators(data["index"])
    fin = data["fin"].copy()
    last = fin.iloc[-1]
    prev = fin.iloc[-2] if len(fin) > 1 else None
    price = px["close"].iloc[-1]

    def nz(x):
        return None if x is None or pd.isna(x) else x

    # --------------------- Trụ cột 1: Chất lượng -----------------------
    q = []
    roe, roa, nm, de = nz(last.get("roe")), nz(last.get("roa")), nz(last.get("net_margin")), nz(last.get("de"))
    rev_g = (last["revenue"] / prev["revenue"] - 1) * 100 if prev is not None and nz(prev["revenue"]) else None
    np_g = (last["npat"] / prev["npat"] - 1) * 100 if prev is not None and nz(prev["npat"]) and prev["npat"] > 0 else None
    is_fin_inst = de is not None and de > 4  # ngân hàng/CTCK: đòn bẩy cao là đặc thù ngành

    _check(q, "ROE ≥ 15%", None if roe is None else roe >= 15, 25, _fmt(roe, "%"))
    _check(q, "ROA ≥ 5%" if not is_fin_inst else "ROA ≥ 1% (tổ chức tài chính)",
           None if roa is None else roa >= (1 if is_fin_inst else 5), 15, _fmt(roa, "%"))
    _check(q, "Biên LN ròng ≥ 10%", None if nm is None else nm >= 10, 15, _fmt(nm, "%"))
    if is_fin_inst:
        _check(q, "Nợ/VCSH (bỏ qua với TCTD)", True, 15, _fmt(de, "x", 2), "Đặc thù ngành tài chính")
    else:
        _check(q, "Nợ/VCSH < 1", None if de is None else de < 1, 15, _fmt(de, "x", 2))
    _check(q, "Tăng trưởng doanh thu ≥ 10%", None if rev_g is None else rev_g >= 10, 15, _fmt(rev_g, "%"))
    _check(q, "Tăng trưởng LNST ≥ 10%", None if np_g is None else np_g >= 10, 15, _fmt(np_g, "%"))

    # --------------------- Trụ cột 2: Định giá -------------------------
    v = []
    pe_hist = fin["pe"].replace([np.inf, -np.inf], np.nan).dropna()
    pb_hist = fin["pb"].replace([np.inf, -np.inf], np.nan).dropna()
    pe_hist = pe_hist[pe_hist > 0]
    eps = nz(last.get("eps"))
    bvps = nz(last.get("bvps"))
    pe_now = price / eps if eps and eps > 0 else nz(last.get("pe"))
    pb_now = price / bvps if bvps and bvps > 0 else nz(last.get("pb"))
    pe_med = pe_hist.median() if len(pe_hist) else None
    pb_med = pb_hist.median() if len(pb_hist) else None

    _check(v, "P/E dương (DN có lãi)", None if pe_now is None else pe_now > 0, 20, _fmt(pe_now, "x"))
    _check(v, "P/E < trung vị lịch sử", None if (pe_now is None or pe_med is None) else 0 < pe_now < pe_med,
           30, f"{_fmt(pe_now, 'x')} vs {_fmt(pe_med, 'x')}")
    _check(v, "P/B < trung vị lịch sử", None if (pb_now is None or pb_med is None) else pb_now < pb_med,
           25, f"{_fmt(pb_now, 'x')} vs {_fmt(pb_med, 'x')}")
    _check(v, "P/E < 15x (mức hợp lý chung)", None if pe_now is None else 0 < pe_now < 15, 25, _fmt(pe_now, "x"))

    # Giá mục tiêu = trung bình (EPS × P/E trung vị, BVPS × P/B trung vị)
    targets = []
    if eps and eps > 0 and pe_med:
        targets.append(eps * pe_med)
    if bvps and bvps > 0 and pb_med:
        targets.append(bvps * pb_med)
    target = float(np.mean(targets)) if targets else None
    upside = (target / price - 1) * 100 if target else None

    # --------------------- Trụ cột 3: Động lượng -----------------------
    m = []
    t = px.iloc[-1]
    rs6 = (_ret(px["close"], 126) - _ret(idx["close"], 126)) * 100 if len(px) > 126 and len(idx) > 126 else None
    regime_bull = idx["close"].iloc[-1] > idx["ma200"].iloc[-1] if not pd.isna(idx["ma200"].iloc[-1]) else None

    _check(m, "Giá > MA50", None if pd.isna(t.ma50) else t.close > t.ma50, 20, f"{_fmt(t.close, '', 0)} / {_fmt(t.ma50, '', 0)}")
    _check(m, "MA50 > MA200 (xu hướng tăng)", None if pd.isna(t.ma200) else t.ma50 > t.ma200, 20,
           f"{_fmt(t.ma50, '', 0)} / {_fmt(t.ma200, '', 0)}")
    _check(m, "RSI 40–70 (không quá mua/bán)", None if pd.isna(t.rsi) else 40 <= t.rsi <= 70, 15, _fmt(t.rsi))
    _check(m, "Mạnh hơn VN-Index 6 tháng", None if rs6 is None else rs6 > 0, 25, _fmt(rs6, " điểm %"))
    _check(m, "VN-Index trên MA200 (thị trường thuận)", regime_bull, 20,
           f"{_fmt(idx['close'].iloc[-1], '', 1)} / {_fmt(idx['ma200'].iloc[-1], '', 1)}")

    def score(items):
        mx = sum(i["max"] for i in items)
        return round(100 * sum(i["pts"] for i in items) / mx, 1) if mx else 0.0

    scores = {"quality": score(q), "valuation": score(v), "momentum": score(m)}
    total = round(sum(scores[k] * w for k, w in WEIGHTS.items()), 1)

    if total >= 70 and (upside is None or upside > 0):
        rec, color = "MUA", (16, 128, 64)
    elif total >= 50:
        rec, color = "THEO DÕI / NẮM GIỮ", (200, 140, 0)
    else:
        rec, color = "TRÁNH / BÁN", (190, 30, 45)

    stop = price - 2 * t.atr if not pd.isna(t.atr) else None

    return dict(
        px=px, idx=idx, fin=fin, price=price,
        checks={"quality": q, "valuation": v, "momentum": m},
        scores=scores, total=total, rec=rec, rec_color=color,
        target=target, upside=upside, stop=stop, atr=t.atr,
        pe_now=pe_now, pb_now=pb_now, pe_med=pe_med, pb_med=pb_med,
        rev_g=rev_g, np_g=np_g, rs6=rs6, regime_bull=regime_bull, rsi=t.rsi,
        ret_1m=_ret(px["close"], 21) * 100, ret_3m=_ret(px["close"], 63) * 100,
        ret_1y=_ret(px["close"], 252) * 100, is_fin_inst=is_fin_inst,
        comments=_comments(scores, rec, upside, rs6, regime_bull, t.rsi, roe, rev_g, np_g),
    )


def _comments(scores, rec, upside, rs6, bull, rsi, roe, rev_g, np_g):
    """Sinh nhận định tự động bằng tiếng Việt."""
    out = []
    qs = scores["quality"]
    out.append(
        f"Chất lượng doanh nghiệp {'tốt' if qs >= 70 else 'trung bình' if qs >= 45 else 'yếu'} "
        f"({qs:.0f}/100)" + (f", ROE đạt {roe:.1f}%" if roe else "") +
        (f"; doanh thu {'tăng' if rev_g >= 0 else 'giảm'} {abs(rev_g):.1f}%" if rev_g is not None else "") +
        (f", LNST {'tăng' if np_g >= 0 else 'giảm'} {abs(np_g):.1f}% so với năm trước." if np_g is not None else ".")
    )
    vs = scores["valuation"]
    out.append(
        f"Định giá {'hấp dẫn' if vs >= 70 else 'hợp lý' if vs >= 45 else 'đắt'} ({vs:.0f}/100)" +
        (f"; giá mục tiêu hàm ý {'dư địa tăng' if upside >= 0 else 'rủi ro giảm'} {abs(upside):.1f}%." if upside is not None else ".")
    )
    ms = scores["momentum"]
    out.append(
        f"Động lượng giá {'mạnh' if ms >= 70 else 'trung tính' if ms >= 45 else 'yếu'} ({ms:.0f}/100)" +
        (f"; cổ phiếu {'vượt' if rs6 > 0 else 'kém'} VN-Index {abs(rs6):.1f} điểm % trong 6 tháng" if rs6 is not None else "") +
        (f", RSI {rsi:.0f}" if not pd.isna(rsi) else "") +
        (f". Thị trường chung đang {'thuận lợi (VN-Index trên MA200)' if bull else 'rủi ro (VN-Index dưới MA200)'}." if bull is not None else ".")
    )
    out.append(f"Tổng hợp: hệ thống đưa ra khuyến nghị {rec}.")
    return out
