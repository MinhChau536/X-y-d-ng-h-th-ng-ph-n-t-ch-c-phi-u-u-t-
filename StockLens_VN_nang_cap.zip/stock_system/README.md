# Hệ thống phân tích cơ hội đầu tư cổ phiếu

## Cài đặt (1 lần)
    pip install -r requirements.txt

## Chạy
Giao diện web:   streamlit run app.py
Dòng lệnh:       python main.py FPT HPG VCB
Khi API lỗi:     python main.py FPT --demo   (dữ liệu mô phỏng, PDF có cảnh báo)

PDF xuất ra thư mục output/.

## Kiến trúc
- analyzer.py : lấy dữ liệu (vnstock – VCI) + chỉ báo kỹ thuật + chấm điểm 3 trụ cột + khuyến nghị
- report.py   : vẽ biểu đồ + xuất PDF 3 trang theo format báo cáo CTCK
- app.py      : giao diện Streamlit, tải PDF theo nhu cầu
- main.py     : chạy hàng loạt từ dòng lệnh
