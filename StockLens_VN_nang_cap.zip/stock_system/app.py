"""StockLens VN – nâng cấp từ stock_system demo.
Chạy: python -m streamlit run app.py
Cần giữ analyzer.py và report.py trong cùng thư mục.
"""
from __future__ import annotations
import datetime as dt
import io
import re
import unicodedata
from pathlib import Path
from urllib.parse import urlparse
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st
from analyzer import load_data, analyze
from report import build_pdf

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
st.set_page_config(page_title='StockLens VN | Phân tích cổ phiếu', page_icon='📈', layout='wide')


def norm(s):
    s = unicodedata.normalize('NFD', str(s or '').lower())
    return re.sub(r'[^a-z0-9]+', '_', ''.join('d' if c == 'đ' else c for c in s if unicodedata.category(c) != 'Mn')).strip('_')

@st.cache_data(show_spinner=False)
def companies():
    f = DATA / 'danh_sach_doanh_nghiep_niem_yet.csv'
    if not f.exists():
        return pd.DataFrame(columns=['ticker','name','industry','exchange'])
    df = pd.read_csv(f, encoding='utf-8-sig', dtype=str).fillna('')
    cols = {norm(k):k for k in df.columns}
    wanted = {'ticker':'ma_ck', 'name':'ten_doanh_nghiep', 'industry':'nganh_icb_cap_1_industry', 'exchange':'san_giao_dich'}
    out = pd.DataFrame({k:df[cols[v]] if v in cols else '' for k,v in wanted.items()})
    out['ticker'] = out['ticker'].str.strip().str.upper()
    return out.drop_duplicates('ticker')

# Hỗ trợ dữ liệu bài báo Excel/CSV đã xuất từ arminer, không giả định có sẵn tin tức.
ALIASES = {
 'ticker':['ticker','symbol','stock_code','ma_ck','ma_chung_khoan'],
 'title':['title','headline','article_title','tieu_de','tieu_de_bai_viet'],
 'content':['content','text','full_text','article_text','noi_dung','clean_text','context'],
 'date':['date','published_at','published_date','publish_date','article_date','ngay_dang','ngay_xuat_ban'],
 'source':['source','source_name','website','nguon','news_source'],
 'url':['url','link','article_url','source_url'],
}
@st.cache_data(show_spinner=False)
def load_news(filebytes, name):
    bio = io.BytesIO(filebytes)
    if name.lower().endswith('.csv'):
        try: df = pd.read_csv(bio, encoding='utf-8-sig')
        except UnicodeDecodeError:
            bio.seek(0); df = pd.read_csv(bio, encoding='cp1258')
    else:
        book = pd.ExcelFile(bio)
        sheet = next((s for s in book.sheet_names if norm(s)=='articles_panel'),book.sheet_names[0])
        df = pd.read_excel(book, sheet_name=sheet)
    names = {norm(c):c for c in df.columns}
    renamed = {}
    for target, possibilities in ALIASES.items():
        for key in possibilities:
            if key in names:
                renamed[names[key]]=target
                break
    df = df.rename(columns=renamed)
    needed = ['title','date']
    if any(k not in df.columns for k in needed):
        raise ValueError(f'Cần cột tiêu đề và ngày đăng. Các cột file: {list(df.columns)}')
    for c in ALIASES:
        if c not in df.columns: df[c]=''
    df['date']=pd.to_datetime(df['date'],errors='coerce',dayfirst=True)
    for c in ['title','content','source','url','ticker']:
        df[c]=df[c].fillna('').astype(str).str.strip()
    df['ticker']=df['ticker'].str.upper()
    df=df.dropna(subset=['date'])
    df=df.loc[df['title'].ne('')].copy()
    df=df.drop_duplicates(subset=['ticker','title','date'])
    return df

EVENTS={
 'Kết quả kinh doanh':['loi nhuan','doanh thu','bao lai','bao lo','ket qua kinh doanh'],
 'Cổ tức/phát hành':['co tuc','phat hanh','esop','chia co phieu'],
 'Dự án/hợp đồng':['trung thau','hop dong','du an','khoi cong','nha may'],
 'Quản trị':['bo nhiem','mien nhiem','hoi dong quan tri','giao dich noi bo'],
 'Pháp lý/rủi ro':['xu phat','thanh tra','truy thu','khoi kien','vi pham'],
 'Vĩ mô/ngành':['lai suat','ty gia','chinh sach','gia nguyen lieu']}
POS=['loi nhuan tang','doanh thu tang','vuot ke hoach','trung thau','tang truong manh']
NEG=['bao lo','loi nhuan giam','doanh thu giam','xu phat','truy thu','vi pham']

def annotate_news(df):
    x=df.copy()
    cats=[]; feelings=[]; impacts=[]; rationales=[]
    for r in x.itertuples():
        sentence=norm(str(r.title)+' '+str(r.content)[:900]).replace('_',' ')
        event_scores={k:sum(word in sentence for word in keys) for k,keys in EVENTS.items()}
        cat=max(event_scores,key=event_scores.get) if event_scores else 'Khác'
        if event_scores and event_scores[cat]==0:cat='Khác'
        p=sum(w in sentence for w in POS); n=sum(w in sentence for w in NEG)
        mood='Tích cực' if p>n else 'Tiêu cực' if n>p else 'Trung lập'
        score=min(100, 30+min(3,event_scores.get(cat,0))*15+(20 if mood!='Trung lập' else 0))
        cats.append(cat);feelings.append(mood);impacts.append(score)
        rationales.append('Quy tắc từ khóa; cần kiểm chứng ngữ cảnh và nguồn gốc')
    x['category']=cats;x['sentiment']=feelings;x['priority_score']=impacts;x['reason']=rationales
    return x

def price_chart(a, ticker, events, overlays):
    df=a['px'].copy()
    fig=make_subplots(rows=2,cols=1,shared_xaxes=True,vertical_spacing=.04,row_heights=[.76,.24])
    fig.add_trace(go.Candlestick(x=df['time'],open=df['open'],high=df['high'],low=df['low'],close=df['close'],name=ticker),row=1,col=1)
    for key,label in [('ma20','SMA20'),('ma50','SMA50'),('ma200','SMA200')]:
        if label in overlays and key in df:
            fig.add_trace(go.Scatter(x=df['time'],y=df[key],name=label,mode='lines'),row=1,col=1)
    if 'Bollinger' in overlays:
        middle=df['close'].rolling(20).mean(); sd=df['close'].rolling(20).std()
        for vals,name in [(middle+2*sd,'BB trên'),(middle-2*sd,'BB dưới')]:
            fig.add_trace(go.Scatter(x=df['time'],y=vals,name=name,line=dict(dash='dot')),row=1,col=1)
    if len(events):
        prices=df.set_index(pd.to_datetime(df['time']).dt.normalize())['close']
        xs=[];ys=[];tips=[]
        for r in events.itertuples():
            date=pd.Timestamp(r.date).normalize()
            future=prices.loc[prices.index>=date]
            if len(future):
                xs.append(future.index[0]);ys.append(float(future.iloc[0]));tips.append(f'{r.title}<br>{r.sentiment} / {r.category}')
        if xs:
            fig.add_trace(go.Scatter(x=xs,y=ys,mode='markers',name='Tin tức',marker=dict(symbol='diamond',size=12),text=tips,hovertemplate='%{text}<extra></extra>'),row=1,col=1)
    fig.add_trace(go.Bar(x=df['time'],y=df['volume'],name='Khối lượng'),row=2,col=1)
    fig.update_layout(height=580,xaxis_rangeslider_visible=False,hovermode='x unified',legend=dict(orientation='h',y=1.09),margin=dict(l=10,r=10,t=45,b=10))
    return fig

def report_bytes(data,a):
    path=ROOT/'output'/f"{data['ticker']}_{dt.datetime.now():%Y%m%d_%H%M%S}.pdf"
    path.parent.mkdir(parents=True,exist_ok=True)
    build_pdf(data,a,str(path))
    return path.read_bytes()

def offline_bot(question, data, a, ev):
    q=norm(question).replace('_',' ')
    if any(word in q for word in ['nguon','cap nhat']):
        return f"Nguồn của dữ liệu phân tích: {data['source']}. Phiên giá cuối: {data['last_session']}. Báo cáo cần đối chiếu BCTC gốc."
    if any(word in q for word in ['tin tuc','su kien','cam xuc']):
        return f"Có {len(ev)} tin phù hợp với mã đang xem. Nhãn cảm xúc tạo bằng từ khóa, không phải tác động giá được kiểm chứng."
    if any(word in q for word in ['rui ro','cat lo','atr']):
        stop=a.get('stop')
        return f"ATR: {a.get('atr',float('nan')):,.0f} VND; mức dừng lỗ tham khảo: {stop:,.0f} VND." if stop is not None else 'Chưa đủ dữ liệu ATR để tính mức dừng lỗ.'
    if any(word in q for word in ['diem','tai sao','phan tich','khuyen nghi']):
        s=a['scores']
        return (f"{data['ticker']}: {a['total']}/100, trạng thái mô hình {a['rec']}. "
                f"Chất lượng {s['quality']:.0f}; Định giá {s['valuation']:.0f}; Động lượng {s['momentum']:.0f}. "
                + ' '.join(a.get('comments',[])[:3]))
    return 'Mình là bot giải thích offline, chỉ trả lời từ dữ liệu phân tích hiện tại. Thử hỏi: “Tại sao điểm thấp?”, “Rủi ro ATR?”, “Nguồn dữ liệu?”, “Tin tức?”.'

st.title('📈 StockLens VN')
st.caption('Phân tích cổ phiếu · Biểu đồ tương tác · Khai phá tin tức · Trợ lý giải thích · PDF')
with st.sidebar:
    st.header('Thiết lập')
    tickers=st.text_input('Mã cổ phiếu (ngăn cách dấu phẩy)','FPT').upper()
    demo=st.toggle('Dữ liệu mô phỏng (chỉ để thử)',value=False)
    st.caption('Tắt mô phỏng để gọi dữ liệu thật qua analyzer.py của bản demo.')
    run=st.button('🚀 Phân tích',type='primary',use_container_width=True)
    st.divider()
    st.markdown('**Dữ liệu tin tức từ công cụ của thầy**')
    upload=st.file_uploader('Articles_Panel (Excel hoặc CSV)',type=['csv','xlsx','xls'])
    st.caption('Hoặc đặt data/news_data.xlsx / data/news_data.csv trong dự án.')
    st.markdown('**Nguồn danh mục**')
    st.caption('data/danh_sach_doanh_nghiep_niem_yet.csv')

news=pd.DataFrame()
try:
    uploaded=None
    if upload:uploaded=(upload.getvalue(),upload.name)
    else:
        for filename in ['news_data.xlsx','news_data.csv']:
            f=DATA/filename
            if f.exists():uploaded=(f.read_bytes(),f.name);break
    if uploaded is not None:
        news=annotate_news(load_news(*uploaded))
except Exception as exc:
    st.warning(f'Chưa đọc được file tin tức: {exc}. Hãy kiểm tra cột tiêu đề/ngày.')

codes=[x.strip() for x in tickers.split(',') if re.fullmatch(r'[A-Z0-9]{2,10}',x.strip())]
if run:
    st.session_state['selected_codes']=codes[:10]
if 'selected_codes' not in st.session_state:st.session_state['selected_codes']=[]

frames={}
if st.session_state['selected_codes']:
    for code in st.session_state['selected_codes']:
        try:
            with st.spinner(f'Đang xử lý {code}...'):
                d=load_data(code,demo=demo); a=analyze(d)
            frames[code]=(d,a)
        except Exception as exc:
            st.error(f'{code}: {exc}')
else:
    st.info('Nhập mã ở thanh bên trái rồi nhấn **Phân tích** để bắt đầu.')

if frames:
    registry=companies()
    lookup=registry.set_index('ticker') if len(registry) else pd.DataFrame()
    tabs=st.tabs(['📊 Phân tích & biểu đồ','📰 Tin tức & sự kiện','🔎 So sánh & sàng lọc','🤖 Trợ lý StockLens','📄 Báo cáo PDF'])
    code=st.selectbox('Mã đang xem',list(frames),key='current_ticker')
    d,a=frames[code]
    code_news=news.loc[(news['ticker']==code) | (news['ticker']=='')].copy() if len(news) else pd.DataFrame()
    with tabs[0]:
        c1,c2,c3,c4=st.columns(4)
        c1.metric('Điểm tổng hợp',f"{a['total']:.1f}/100")
        c2.metric('Trạng thái mô hình',a['rec'])
        c3.metric('Giá gần nhất',f"{a['price']:,.0f} VND")
        c4.metric('RSI14',f"{a['rsi']:.1f}" if pd.notna(a['rsi']) else 'N/A')
        if demo:st.warning('DỮ LIỆU MÔ PHỎNG – Không được dùng làm khuyến nghị đầu tư thực tế.')
        opts=st.multiselect('Chỉ báo trên biểu đồ',['SMA20','SMA50','SMA200','Bollinger'],default=['SMA20','SMA50'])
        show_events=st.checkbox('Gắn tin tức lên biểu đồ',value=True)
        st.plotly_chart(price_chart(a,code,code_news if show_events else pd.DataFrame(),opts),use_container_width=True)
        st.subheader('Giải thích điểm 3 trụ cột')
        st.write(pd.DataFrame([{'Nhân tố':key,'Điểm':round(value,1)} for key,value in a['scores'].items()]))
        for k, label in [('quality','Chất lượng'),('valuation','Định giá'),('momentum','Động lượng')]:
            with st.expander(f'Chi tiết {label}'):
                st.dataframe(pd.DataFrame(a['checks'][k]),use_container_width=True,hide_index=True)
        for comment in a.get('comments',[]):st.write('•',comment)
        st.caption(f"Nguồn: {d['source']} | Phiên cuối: {d['last_session']} | Lấy lúc {d['fetched_at']}")
    with tabs[1]:
        if news.empty:st.warning('Chưa có dữ liệu bài báo. Xuất Articles_Panel trong arminer rồi upload ở thanh bên trái.')
        else:
            f=news.copy()
            col1,col2,col3=st.columns(3)
            with col1:
                selected=st.multiselect('Mã chứng khoán',sorted(f['ticker'].unique()),default=[code] if code in f['ticker'].values else [])
                category=st.multiselect('Loại sự kiện',sorted(f['category'].unique()))
            with col2:
                sentiment=st.multiselect('Sắc thái',sorted(f['sentiment'].unique()))
                priority=st.slider('Điểm ưu tiên tối thiểu',0,100,0,5)
            with col3:
                source=st.multiselect('Nguồn tin',sorted(f['source'].unique()))
                word=st.text_input('Từ khóa tiêu đề/nội dung')
            dates=st.date_input('Ngày xuất bản',value=(f['date'].min().date(),f['date'].max().date()))
            if selected:f=f[f['ticker'].isin(selected)]
            if category:f=f[f['category'].isin(category)]
            if sentiment:f=f[f['sentiment'].isin(sentiment)]
            if source:f=f[f['source'].isin(source)]
            f=f[f['priority_score']>=priority]
            if word:
                needle=norm(word)
                mask=(f['title']+' '+f['content']).map(norm).str.contains(needle,regex=False)
                f=f[mask]
            if isinstance(dates,(tuple,list)) and len(dates)==2:
                f=f[(f['date'].dt.date>=dates[0]) & (f['date'].dt.date<=dates[1])]
            if len(registry) and 'industry' in registry:
                industry=st.selectbox('Ngành', ['Tất cả']+sorted([v for v in registry['industry'].unique() if v]))
                if industry!='Tất cả':
                    eligible=registry.loc[registry['industry']==industry,'ticker']
                    f=f[f['ticker'].isin(eligible)]
            st.metric('Tin phù hợp',len(f))
            if len(f):
                st.bar_chart(f['sentiment'].value_counts())
                for row in f.sort_values(['date','priority_score'],ascending=False).head(60).itertuples():
                    st.markdown(f"**{row.title}**")
                    st.caption(f"{row.ticker} · {row.date:%d/%m/%Y} · {row.source} · {row.category} · {row.sentiment} · {row.priority_score}/100 ưu tiên")
                    if str(row.url).startswith(('https://','http://')):st.link_button('Đọc nguồn',row.url)
                    with st.expander('Nội dung và cách chấm'):
                        st.write(row.content[:2200] or 'Không có toàn văn bài báo')
                        st.info(row.reason)
            st.download_button('Tải bảng tin đã lọc',f.to_csv(index=False).encode('utf-8-sig'),'news_filtered.csv','text/csv')
            st.caption('Sắc thái và điểm ưu tiên tính bằng từ khóa; không phải điểm tác động giá hoặc xác suất lợi nhuận.')
    with tabs[2]:
        records=[]
        for t,(dd,aa) in frames.items():
            info=lookup.loc[t] if len(lookup) and t in lookup.index else None
            records.append({'Mã':t,'Doanh nghiệp':info['name'] if info is not None else dd['name'],'Ngành':info['industry'] if info is not None else dd.get('industry',''),'Tổng điểm':aa['total'],'Chất lượng':aa['scores']['quality'],'Định giá':aa['scores']['valuation'],'Động lượng':aa['scores']['momentum'],'Nhận định':aa['rec']})
        table=pd.DataFrame(records)
        min_score=st.slider('Điểm tổng hợp tối thiểu',0,100,0)
        st.dataframe(table[table['Tổng điểm']>=min_score].sort_values('Tổng điểm',ascending=False),use_container_width=True,hide_index=True)
        st.caption('Chỉ xếp hạng các mã đã được phân tích trong phiên hiện tại, không phải toàn thị trường.')
    with tabs[3]:
        st.subheader('StockLens Assistant – giải thích từ dữ liệu hiện có')
        st.caption('Bot offline, KHÔNG gọi API AI, không tự đọc web, không thể trả lời ngoài dữ liệu đang phân tích.')
        q=st.chat_input(f'Hỏi về {code}: Tại sao điểm thấp? Rủi ro? Tin tức?')
        if q:
            st.session_state.setdefault('chatlog',[]).append(('user',q))
            st.session_state['chatlog'].append(('assistant',offline_bot(q,d,a,code_news)))
        for role,message in st.session_state.get('chatlog',[]):
            with st.chat_message(role):st.write(message)
    with tabs[4]:
        st.subheader(f'Báo cáo đầu tư {code}')
        st.info('PDF được tạo bởi report.py gốc. Hiện bao gồm phân tích 3 trụ cột; phần tin tức tùy chọn chưa được nhúng vào PDF.')
        try:
            pdf=report_bytes(d,a)
            st.download_button('⬇️ Tải báo cáo PDF',pdf,f'StockLens_{code}.pdf','application/pdf',type='primary')
        except Exception as exc:st.error(f'Lỗi tạo PDF: {exc}')
        st.caption('Báo cáo chỉ phục vụ học tập, không phải tư vấn đầu tư cá nhân.')
